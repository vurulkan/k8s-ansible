Anlatım için;
https://dev.azure.com/ZeniaProjects/Hospitality/_wiki?pageId=2170&friendlyName=Ansible-%C4%B0le-Kubernetes-HA-Cluster-Kurulumu-(HAProxy-Keepalived)-(RHEL9)